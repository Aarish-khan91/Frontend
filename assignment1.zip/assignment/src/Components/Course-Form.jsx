import React from 'react'
import { Box, TextField, Button, FormControl, FormHelperText, Stack } from '@mui/material';

function CourseForm() {
    return (
        <Box sx={{ width: '350px' }}>
            <FormControl fullWidth margin="normal">

                <Stack mb={1}>
                    <TextField
                        label="Course title"
                        variant="outlined"
                    />
                </Stack>

                <Stack mb={1}>
                    <TextField
                        label="Course Code"
                        variant="outlined"
                    />
                </Stack>

                <Stack mb={1}>
                    <TextField
                        label="Course description"
                        variant="outlined"
                    />
                </Stack>

            </FormControl>

            <Box sx={{ textAlign: 'center', textTransform: 'capitalize' }} >
                <Button sx={{ textTransform: 'capitalize', bgcolor:'#1976d2' }} type="submit" variant="contained">
                    Add course
                </Button>
            </Box>
        </Box>
    )
}

export default CourseForm
