import { Box, Button, FormControl, InputLabel, MenuItem, Select, Stack, TextField, useMediaQuery, useTheme } from '@mui/material';
import React from 'react';

function CourseSelection() {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

    return (
        <Box sx={{ mt: 3, display: 'flex', flexDirection: 'column', px: 2 }}>
            <FormControl fullWidth>
                <Stack direction={isMobile ? 'column' : 'row'} alignItems={isMobile ? 'flex-start' : 'center'} gap={3} mb={2}>
                    <InputLabel id="demo-simple-select-label">Select course</InputLabel>
                    <Select
                        sx={{
                            width: isMobile ? '100%' : '150px',
                            '& .MuiOutlinedInput-notchedOutline': {
                                border: 'none',
                            },
                        }}
                        labelId="demo-simple-select-label"
                    >
                        <MenuItem value={10}>Ten</MenuItem>
                    </Select>
                    <Box>
                        <Button 
                            variant='contained' 
                            sx={{ 
                                pt: 0, 
                                pb: 0, 
                                textTransform: 'capitalize',
                                width: isMobile ? '100%' : 'auto'
                            }}
                        >
                            Refresh
                        </Button>
                    </Box>
                </Stack>

                <Stack direction={isMobile ? 'column' : 'row'} gap={2}>
                    <TextField 
                        type='text' 
                        label='Year' 
                        sx={{ 
                            width: isMobile ? '100%' : '100px',
                            mb: isMobile ? 2 : 0
                        }} 
                    />
                    <TextField 
                        type='text' 
                        label='Semester' 
                        sx={{ 
                            width: isMobile ? '100%' : '150px' 
                        }} 
                    />
                </Stack>
            </FormControl>
            <Box mt={3} sx={{ textAlign: 'center' }}>
                <Button variant='contained' sx={{ textTransform: 'capitalize', width: isMobile ? '100%' : 'auto' }}>
                    Add instance
                </Button>
            </Box>
        </Box>
    );
}

export default CourseSelection;
