import React, { useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button, Box, IconButton, useMediaQuery, useTheme, Stack, TextField, Select, MenuItem, InputLabel, FormControl } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import DeleteIcon from '@mui/icons-material/Delete';
import { useLocation, useNavigate } from 'react-router-dom';

function CoursesList() {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

    const location = useLocation();
    const pathName = location.pathname;
    const navigate = useNavigate();

    // State for filtering
    const [filterYear, setFilterYear] = useState('');
    const [selectedSemester, setSelectedSemester] = useState('');
    const [filteredCourses, setFilteredCourses] = useState([]);

    // Sample data
    const courses = [
        { title: 'Introduction to React', code: 'RE101', semester: '1', year: 2023 },
        { title: 'Advanced JavaScript', code: 'JS201', semester: '1', year: 2021 },
        { title: 'Data Structures', code: 'DS301', semester: '1', year: 2024 },
        { title: 'Algorithms', code: 'AL401', semester: '1', year: 2020 },
    ];

    // Handle filter button click
    const handleFilter = () => {
        const filtered = courses.filter(course =>
            (filterYear ? course.year.toString().startsWith(filterYear) : true) &&
            (selectedSemester ? course.semester === selectedSemester : true)
        );
        setFilteredCourses(filtered);
    };

    React.useEffect(() => {
        setFilteredCourses(courses);
    }, [pathName]);

    return (
        <Box sx={{ p: 1 }}>

            {pathName === '/courses' && (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 3, mb: 2 }}>
                    <Stack direction='row' gap={3}>
                        <TextField
                            type='text'
                            label='Year'
                            value={filterYear}
                            onChange={(e) => setFilterYear(e.target.value)}
                            sx={{
                                width: isMobile ? '100%' : '150px',
                                mb: isMobile ? 2 : 0
                            }}
                        />
                        <FormControl sx={{ width: isMobile ? '100%' : '170px' }}>
                            <InputLabel id="demo-simple-select-label">Select Semester</InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                value={selectedSemester}
                                onChange={(e) => setSelectedSemester(e.target.value)}
                                sx={{
                                    '& .MuiOutlinedInput-notchedOutline': {
                                        border: 'none',
                                    },
                                }}
                            >
                                {courses.map((item, index) => (
                                    <MenuItem key={index} value={item.semester}>{item.semester}</MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                    </Stack>

                    <Box sx={{ textAlign: 'center' }}>
                        <Button variant='contained' sx={{ textTransform: 'capitalize' }} onClick={handleFilter}>List instances</Button>
                    </Box>

                </Box>
            )}

            {pathName === '/' && (
                <Box sx={{ textAlign: 'center' }}>
                    <Button variant='contained' sx={{ textTransform: 'capitalize' }} onClick={() => navigate('/courses')}>List courses</Button>
                </Box>
            )}

            <TableContainer component={Paper} sx={{ mt: 1, width: '100%', overflowX: 'auto' }}>
                <Table sx={{ borderCollapse: 'collapse' }}>
                    <TableHead sx={{ bgcolor: '#5a80fb', color: 'white' }}>
                        <TableRow>
                            <TableCell sx={{ color: 'white', fontSize: isMobile ? '0.8rem' : '1rem', border: '1px solid #e0e0e0' }}>Course Title</TableCell>
                            {pathName === '/courses' && <TableCell sx={{ color: 'white', fontSize: isMobile ? '0.8rem' : '1rem', border: '1px solid #e0e0e0' }}>Year-Sem</TableCell>}
                            <TableCell sx={{ color: 'white', fontSize: isMobile ? '0.8rem' : '1rem', border: '1px solid #e0e0e0' }}>Code</TableCell>
                            <TableCell sx={{ color: 'white', fontSize: isMobile ? '0.8rem' : '1rem', border: '1px solid #e0e0e0' }}>Action</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {filteredCourses.map((course, index) => (
                            <TableRow key={index}
                                sx={{
                                    backgroundColor: index % 2 === 1 ? '#f5f5f5' : 'white',
                                    height: 'auto',
                                    fontSize: isMobile ? '0.75rem' : '1rem',
                                    '&:last-child td, &:last-child th': { border: 0 }
                                }}>
                                <TableCell sx={{ border: '1px solid #e0e0e0' }}>{course.title}</TableCell>
                                {pathName === '/courses' && <TableCell sx={{ border: '1px solid #e0e0e0' }}>{course.year}-{course.semester}</TableCell>}
                                <TableCell sx={{ border: '1px solid #e0e0e0', width: '150px' }}>{course.code}</TableCell>
                                <TableCell sx={{ border: '1px solid #e0e0e0', width: '150px' }}>
                                    <IconButton color="primary" size="small">
                                        <SearchIcon sx={{ bgcolor: 'black', p: '2px', borderRadius: '5px', color: 'white' }} fontSize="small" />
                                    </IconButton>
                                    <IconButton color="error" size="small">
                                        <DeleteIcon sx={{ color: 'black' }} fontSize="small" />
                                    </IconButton>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>

        </Box>
    );
}

export default CoursesList;
