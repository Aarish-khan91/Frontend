import React from 'react'
import CourseSelection from './Course-selection'
import CoursesList from './Courses-List'
import CourseForm from './Course-Form';
import Box from '@mui/material/Box';
import { Divider, Stack } from '@mui/material';

function Main() {
    return (
        <Box sx={{ p: 2 }}>

            <Stack direction='row' alignItems='center' gap={{ xs: 10, md: 20 }} sx={{}}>
                <CourseForm />
                <CourseSelection />
            </Stack>

            <Divider sx={{ mt: 1, border: '1px solid #e0e0e0' }} />

            <Box sx={{ pl: { xs: 0, md: 30 } }}>
                <CoursesList />
            </Box>

        </Box>

    )
}

export default Main
